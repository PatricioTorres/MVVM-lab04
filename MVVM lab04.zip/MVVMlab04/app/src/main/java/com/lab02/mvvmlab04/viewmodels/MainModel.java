package com.lab02.mvvmlab04.viewmodels;

public class MainModel {

}
